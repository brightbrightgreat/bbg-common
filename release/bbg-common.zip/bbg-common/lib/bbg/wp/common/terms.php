<?php
 namespace bbg\wp\common; use \WP_Term; class terms { public static function get_terms_by_post_type( array $args ) { if (!isset($args['taxonomies']) || !isset($args['post_types']) || !is_array($args['taxonomies']) || !is_array($args['post_types'])) { return false; } global $wpdb; $query = $wpdb->prepare( "SELECT t.term_id from $wpdb->terms AS t
				INNER JOIN $wpdb->term_taxonomy AS tt ON t.term_id = tt.term_id
				INNER JOIN $wpdb->term_relationships AS r ON r.term_taxonomy_id = tt.term_taxonomy_id
				INNER JOIN $wpdb->posts AS p ON p.ID = r.object_id
				WHERE
					p.post_type IN('%s') AND
					p.post_status = 'publish' AND
					tt.taxonomy IN('%s')
				GROUP BY t.term_id", join( "', '", $args['post_types'] ), join( "', '", $args['taxonomies'] ) ); $results = $wpdb->get_results( $query, ARRAY_A ); if (!is_array($results) || !count($results)) { return null; } $term_ids = array(); foreach ($results as $row) { $term_ids[] = (int) $row['term_id']; } $terms = get_terms(array( 'include'=>$term_ids, )); return $terms; } public static function get_terms_by_intersection(WP_Term $term, string $taxonomy, string $post_type='post') { $out = array(); if (!is_a($term, 'WP_Term') || !$taxonomy) { return $out; } $posts = get_posts(array( 'post_type'=>$post_type, 'numberposts'=>-1, 'numberposts'=>-1, 'tax_query'=>array( array( 'taxonomy'=>$term->taxonomy, 'field'=>'id', 'terms'=>$term->term_id, 'include_children'=>false, ), ), )); if (!is_array($posts) || !count($posts)) { return $out; } $post_ids = array(); foreach ($posts as $v) { $post_ids[] = (int) $v->ID; } $out = get_terms(array( 'taxonomy'=>$taxonomy, 'object_ids'=>$post_ids, )); return $out; } } 